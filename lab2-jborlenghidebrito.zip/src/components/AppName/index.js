export default function Header() {
  return (
    <h3 style={{ color: "white", margin: 0, marginLeft: -30 }}>
      Todo App - by Jennifer Borlenghi de Brito
    </h3>
  );
}
